module org.example.tabla2pantallas {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.tabla2pantallas to javafx.fxml;
    exports org.example.tabla2pantallas;
}
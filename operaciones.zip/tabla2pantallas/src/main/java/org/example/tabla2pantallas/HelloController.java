package org.example.tabla2pantallas;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {

    @FXML
    private Button btnAgregar;
    @FXML
    private TableView<Persona> tblPersonas;

    // CORRECCIÓN 1: Quitamos 'static'. Cada ventana debe tener su propia instancia de lista.
    private ObservableList<Persona> personas;

    @FXML
    private javafx.scene.control.TableColumn<Persona, String> colNombre;
    @FXML
    private javafx.scene.control.TableColumn<Persona, String> colApellido;
    @FXML
    private javafx.scene.control.TableColumn<Persona, Integer> colEdad;
    @FXML
    private TextField txtBuscar;

    @FXML
    public void initialize() {
        // Inicializamos la lista aquí
        personas = FXCollections.observableArrayList();
        this.tblPersonas.setItems(personas);

        this.colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        this.colApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        this.colEdad.setCellValueFactory(new PropertyValueFactory<>("edad"));
    }

    @FXML
    protected Persona seleccionar() {
        return this.tblPersonas.getSelectionModel().getSelectedItem();
    }
    @FXML
    protected void agregar() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("formulario-view.fxml"));
            Parent root = loader.load();

            // Obtener el controlador del formulario
            FormularioController controlador = loader.getController();

            // CORRECCIÓN 2: PASO CRÍTICO DE DATOS

            if (personas == null) {
                System.out.println("Error: La lista 'personas' es null antes de enviarla.");
                personas = FXCollections.observableArrayList(); // Recuperación de emergencia
            }
            controlador.initAttributtes(personas);

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Nueva persona");
            stage.setScene(scene);
            stage.showAndWait();

            // Recoger la persona creada
            Persona p = controlador.getPersona();
            if (p != null) {
                this.personas.add(p);
                this.tblPersonas.refresh();
            }

        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("No se pudo abrir la ventana del formulario: " + e.getMessage());
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    @FXML
    protected void modificar() {
        Persona seleccionada = this.tblPersonas.getSelectionModel().getSelectedItem();

        if (seleccionada == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Atención");
            alert.setHeaderText(null);
            alert.setContentText("Debe seleccionar una persona de la tabla.");
            alert.showAndWait();
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("formulario-view.fxml"));
            Parent root = loader.load();

            FormularioController controlador = loader.getController();

            // CORRECCIÓN 3: También pasamos la lista en modificar
            controlador.initAttributtes(personas, seleccionada);

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Modificar persona");
            stage.setScene(scene);
            stage.showAndWait();

            this.tblPersonas.refresh();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void eliminar() {
        Persona personaSeleccionada = this.tblPersonas.getSelectionModel().getSelectedItem();

        if (personaSeleccionada != null) {
            personas.remove(personaSeleccionada);
            tblPersonas.refresh();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información");
            alert.setHeaderText(null);
            alert.setContentText("Persona eliminada correctamente.");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Advertencia");
            alert.setHeaderText(null);
            alert.setContentText("Por favor, seleccione una persona para eliminar.");
            alert.showAndWait();
        }
    }

    // Método auxiliar buscar (simplificado)
    public void buscar() {
        String nombreBuscado = this.txtBuscar.getText().toLowerCase();
        ObservableList<Persona> filtrados = FXCollections.observableArrayList();

        for(Persona p : personas){
            if(p.getNombre().toLowerCase().contains(nombreBuscado)){
                filtrados.add(p);
            }
        }
        this.tblPersonas.setItems(filtrados);
    }
}
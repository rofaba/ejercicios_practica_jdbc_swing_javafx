package org.example.tabla2pantallas;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FormularioController {

    private Persona persona;
    private ObservableList<Persona> listaPersonas;
    private boolean modoEdicion = false;

    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApellido;
    @FXML
    private TextField txtEdad;
    @FXML
    private Button btnGuardar;
    @FXML
    private Button btnSalir;

    public void initialize() {
    }

    // ALTA (nueva persona)
    public void initAttributtes(ObservableList<Persona> listaPersonas) {
        this.listaPersonas = listaPersonas;
        this.modoEdicion = false;
    }

    // EDICIÓN (persona existente)
    public void initAttributtes(ObservableList<Persona> listaPersonas, Persona persona) {
        this.listaPersonas = listaPersonas;
        this.persona = persona;
        this.modoEdicion = true;

        // Rellenar campos con la persona seleccionada
        txtNombre.setText(persona.getNombre());
        txtApellido.setText(persona.getApellido());
        txtEdad.setText(String.valueOf(persona.getEdad()));
    }

    @FXML
    void guardar(ActionEvent event) {

        // 1. SEGURIDAD: Verificar que la lista se ha recibido
        if (listaPersonas == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error de Sistema");
            alert.setHeaderText("Error de inicialización");
            alert.setContentText("La lista de personas no ha sido inicializada en el controlador.");
            alert.showAndWait();
            return;
        }

        String nombre = this.txtNombre.getText();
        String apellido = this.txtApellido.getText();

        // Validación básica de campos vacíos
        if (nombre.isEmpty() || apellido.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Datos incompletos");
            alert.setContentText("Por favor rellene nombre y apellido");
            alert.showAndWait();
            return;
        }

        try {
            int edad = Integer.parseInt(this.txtEdad.getText());

            if (modoEdicion) {
                // MODO EDICIÓN
                persona.setNombre(nombre);
                persona.setApellido(apellido);
                persona.setEdad(edad);

                // Cerrar
                Stage stage = (Stage) btnGuardar.getScene().getWindow();
                stage.close();

            } else {
                // MODO ALTA
                Persona p = new Persona(nombre, apellido, edad);

                if (!listaPersonas.contains(p)) {
                    this.persona = p;

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Éxito");
                    alert.setContentText("Persona agregada correctamente.");
                    alert.showAndWait();

                    Stage stage = (Stage) btnGuardar.getScene().getWindow();
                    stage.close();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setContentText("La persona ya existe.");
                    alert.showAndWait();
                }
            }
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("La edad debe ser un número válido.");
            alert.showAndWait();
        }
    }
    @FXML
    void salir(ActionEvent event) {
        this.persona = null;
        Stage stage = (Stage) btnSalir.getScene().getWindow();
        stage.close();

    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona nueva) {
        this.persona = nueva;
    }

    public ObservableList<Persona> getListaPersonas() {
        return listaPersonas;
    }

    public void setListaPersonas(ObservableList<Persona> listaPersonas) {
        this.listaPersonas = listaPersonas;


    }
}
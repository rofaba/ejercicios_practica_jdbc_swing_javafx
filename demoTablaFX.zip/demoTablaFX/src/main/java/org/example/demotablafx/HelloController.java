package org.example.demotablafx;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class HelloController {

    @FXML
    private Button btnAgregar;

    @FXML
    private TableColumn colApellido;

    @FXML
    private TableColumn colEdad;

    @FXML
    private TableColumn colNombre;

    @FXML
    private TableView<Persona> tblPersona;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtEdad;

    @FXML
    private TextField txtNombre;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button btnModificar;


    @FXML
    private ObservableList<Persona> listaPersonas;

    public void initialize() {
        listaPersonas = FXCollections.observableArrayList();
        this.colNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.colApellido.setCellValueFactory(new PropertyValueFactory("apellido"));
        this.colEdad.setCellValueFactory(new PropertyValueFactory("edad"));

    }

    @FXML
    void agregarPersona() {
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        int edad = Integer.parseInt(txtEdad.getText());

        Persona p = new Persona(nombre, apellido, edad);

        try {
            if (!this.listaPersonas.contains(p)) {
                this.listaPersonas.add(p);
                this.tblPersona.setItems(listaPersonas);
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Información");
                alert.setHeaderText(null);
                alert.setContentText("La persona ya existe en la lista.");
                alert.showAndWait();
            }
        } catch (NumberFormatException e) {
        }

        txtNombre.clear();
        txtApellido.clear();
        txtEdad.clear();
    }

    @FXML
    void seleccionar() {
        Persona p = this.tblPersona.getSelectionModel().getSelectedItem();
        if (p != null) {
            this.txtNombre.setText(p.getNombre());
            this.txtApellido.setText(p.getApellido());
            this.txtEdad.setText(String.valueOf(p.getEdad()));
        }

    }
    @FXML
    void modificar() {
        Persona p = this.tblPersona.getSelectionModel().getSelectedItem();
        if (p != null) {
            String nombre = txtNombre.getText();
            String apellido = txtApellido.getText();
            int edad = Integer.parseInt(txtEdad.getText());

            p.setNombre(nombre);
            p.setApellido(apellido);
            p.setEdad(edad);

            this.tblPersona.refresh();
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información");
            alert.setHeaderText(null);
            alert.setContentText("Seleccione una persona para modificar.");
            alert.showAndWait();
        }
    }

    @FXML
    void eliminar() {
        Persona p = this.tblPersona.getSelectionModel().getSelectedItem();
        if (p != null) {
            this.listaPersonas.remove(p);
            this.tblPersona.setItems(listaPersonas);
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información");
            alert.setHeaderText(null);
            alert.setContentText("Seleccione una persona para eliminar.");
            alert.showAndWait();
        }
    }
}
